import "./chunk-L6OFPWCY.js";

// node_modules/.pnpm/@nolebase+vitepress-plugin-_0aefca1d2bc45263c3111357ba58a13a/node_modules/@nolebase/vitepress-plugin-highlight-targeted-heading/dist/client/index.mjs
import NolebaseHighlightTargetedHeading from "C:/Users/23771/Desktop/xmu/node_modules/.pnpm/@nolebase+vitepress-plugin-_0aefca1d2bc45263c3111357ba58a13a/node_modules/@nolebase/vitepress-plugin-highlight-targeted-heading/dist/client/components/HighlightTargetedHeading.vue";
var components = {
  NolebaseHighlightTargetedHeading
};
var NolebaseNolebaseHighlightTargetedHeadingPlugin = {
  install(app) {
    for (const key of Object.keys(components))
      app.component(key, components[key]);
  }
};
export {
  NolebaseHighlightTargetedHeading,
  NolebaseNolebaseHighlightTargetedHeadingPlugin
};
//# sourceMappingURL=@nolebase_vitepress-plugin-highlight-targeted-heading_client.js.map
