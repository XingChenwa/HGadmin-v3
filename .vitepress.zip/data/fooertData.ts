import type { FooterData } from '@theojs/lumen'

export const Footer_Data: FooterData = {
  author: { name: 'ikenxuan', link: 'https://github.com/ikenxuan' },
  group: [
    {
      title: '友情链接',
      icon: 'fa-solid fa-handshake',
      links: [
        { name: '个人博客', href: 'https://www.q2.hk' },
        { name: 'CFX论坛', href: 'https://forum.cfx.re/' },
        { name: 'FiveM', href: 'https://fivem.net/' },
        { name: 'FiveM最强解密网站', href: 'https://fxap.web.1239.xin:883/' },
      ]
    },
    {
      title: '相关链接',
      icon: 'fab fa-github',
      links: [
        { name: 'ESX框架', href: 'https://github.com/esx-framework/esx_core' },
        { name: 'QB框架', href: 'https://qbcore.net/' },
      ]
    },
  ]
}